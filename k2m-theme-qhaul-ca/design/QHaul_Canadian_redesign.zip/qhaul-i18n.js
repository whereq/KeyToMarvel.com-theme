/* QHaul.ca — shared locale strings for cn (default), en, fr */
window.QHAUL_I18N = {
  cn: {
    label: "中文", labelShort: "中", locName: "简体中文",
    navHome: "首页", navQuote: "报价", navTrack: "追踪", navBusiness: "商务账户", navDrivers: "成为司机", navAccount: "我的订单",
    signIn: "登录", signOut: "退出登录", signedInAs: "已登录",
    region: "大多伦多地区 · 安大略省 · 加拿大",
    heroTitle: "需要搬运？QHaul 帮你搞定。",
    heroSub: "本地司机，真实的人，当日上门。搬家、配送、清运、二手取货，一个平台全部解决。",
    ctaQuote: "立即报价", ctaTrack: "追踪订单",
    statJobs: "每月完成订单", statSameDay: "当日达成率", statPickup: "平均上门时间",
    quickQuote: "快速报价", pickup: "取货地址", dropoff: "送达地址", service: "服务类型",
    pickupPh: "街道、城市或邮编", dropoffPh: "街道、城市或邮编",
    servicesTitle: "我们搬什么", servicesSub: "四种服务，一个平台，始终是同一批本地司机。",
    svc: [
      { t: "搬家", b: "公寓搬迁、单件搬运、家具调换。" },
      { t: "配送", b: "当日快递、商家直送、退货取件。" },
      { t: "清运", b: "垃圾清运、家电回收、大件处理。" },
      { t: "二手取货", b: "Kijiji、Facebook Marketplace、拍卖取货。" }
    ],
    svcCta: "开始报价",
    howTitle: "三步完成",
    steps: [
      { t: "填写地址与时间", b: "输入取送地址，选择当日或预约时段。" },
      { t: "选择车型", b: "从小型货车到五吨卡车，价格提前透明可见。" },
      { t: "司机上门，实时追踪", b: "接单后即可查看司机位置、车牌与预计到达时间。" }
    ],
    localEyebrow: "本地承运",
    localTitle: "不是算法派单，是你附近的司机。",
    localBody: "QHaul 的司机常驻大多伦多地区，熟悉小区门禁、电梯预约与装卸规则。每一单都由真人负责到底。",
    b2bTitle: "商务账户", b2bCta: "申请开户",
    b2b: [
      { t: "月结发票", b: "Net 15 / Net 30" },
      { t: "批量价格", b: "按月单量阶梯" },
      { t: "系统对接", b: "REST API · Webhook" }
    ],
    quoteTitle: "获取报价", quoteSub: "预计一分钟完成",
    whenLabel: "取货时间", sizeLabel: "货物体积", vehicleLabel: "选择车型",
    contactLabel: "联系方式", notesLabel: "备注（门禁、楼层、电梯）",
    notesPh: "例如：后门装卸，需预约货梯 14:00–15:00",
    helperLabel: "需要额外一名搬运工（+$45 / 小时）",
    estimate: "价格预估", total: "合计", bookNow: "确认下单",
    priceNote: "预估含燃油与两段各 15 分钟装卸时间，不含 HST。超时按分钟计费。",
    vehicles: [
      { n: "小型货车", c: "最多 40 立方英尺 · 1 人", p: "$49 起" },
      { n: "厢式货车", c: "最多 250 立方英尺 · 1 人", p: "$79 起" },
      { n: "方箱卡车", c: "最多 600 立方英尺 · 2 人", p: "$129 起" },
      { n: "五吨卡车", c: "整屋搬迁 · 2–3 人", p: "$189 起" }
    ],
    priceRows: [
      { l: "基础费用（厢式货车）", v: "$79.00" },
      { l: "里程 24.8 km", v: "$37.20" },
      { l: "装卸 30 分钟", v: "已含" },
      { l: "额外搬运工", v: "$45.00" }
    ],
    total_v: "$161.20",
    trackTitle: "追踪订单", trackCta: "查询", statusLabel: "当前状态", statusNow: "正在配送",
    trackPh: "输入订单号，例如 QH-2026-04871",
    mapNote: "实时路线 · 每 15 秒更新",
    driverLabel: "承运司机", callDriver: "联系司机", shareEta: "分享预计到达",
    timeline: [
      { t: "订单已创建", b: "线上支付授权完成", m: "13:42" },
      { t: "司机已接单", b: "Wei L. · 方箱卡车 · CBTK 481", m: "13:47" },
      { t: "已到达取货点", b: "401 Bay St, Toronto", m: "14:05" },
      { t: "正在配送", b: "距送达地点 8.2 km", m: "14:31" },
      { t: "已送达", b: "等待签收照片", m: "预计 14:55" }
    ],
    accountTitle: "我的订单", newBooking: "新建订单",
    accountTiles: [
      { v: "3", l: "进行中" }, { v: "27", l: "已完成" }, { v: "$1,940", l: "本月支出" }, { v: "Net 30", l: "结算方式" }
    ],
    colId: "订单号", colRoute: "路线", colService: "服务", colStatus: "状态", colTotal: "金额",
    bookings: [
      { id: "QH-2026-04871", r: "401 Bay St → 88 Mill St", s: "配送", st: "配送中", tt: "$161.20" },
      { id: "QH-2026-04844", r: "12 Yonge St → 900 King St W", s: "搬家", st: "已完成", tt: "$412.00" },
      { id: "QH-2026-04810", r: "66 Wellesley St → 弃置站", s: "清运", st: "已完成", tt: "$228.50" },
      { id: "QH-2026-04788", r: "Kijiji 卖家 → 55 Bloor St", s: "二手取货", st: "已完成", tt: "$96.00" },
      { id: "QH-2026-04771", r: "Mississauga → Scarborough", s: "配送", st: "已取消", tt: "$0.00" }
    ],
    bizTitle: "为车队与门店而建的商务账户",
    bizSub: "统一后台、月结发票、批量价格。把最后一公里交给本地司机。",
    bizCta: "申请开户", bizCta2: "预约演示",
    bizFeatures: [
      { t: "月结发票", b: "Net 15 或 Net 30，按月合并对账，支持多成本中心。" },
      { t: "批量价格", b: "按月单量自动进入阶梯价，无需重新谈判。" },
      { t: "API 对接", b: "REST 下单、Webhook 状态回调、批量导入 CSV。" },
      { t: "专属客服", b: "工作时段内 15 分钟响应，异常单人工介入。" }
    ],
    bizTiersTitle: "价格阶梯", bizTierCols: ["每月单量", "折扣", "结算"],
    bizTiers: [
      { a: "1 – 49", b: "标准价", c: "信用卡" },
      { a: "50 – 199", b: "-8%", c: "Net 15" },
      { a: "200 – 499", b: "-14%", c: "Net 30" },
      { a: "500+", b: "面议", c: "Net 30 + 专属车辆" }
    ],
    driverTitle: "开车赚钱，按周结算",
    driverSub: "自带车辆，自选时段。大多伦多地区每周结款，无加盟费。",
    driverCta: "开始注册", driverCta2: "查看收入说明",
    driverReqTitle: "注册条件",
    driverReq: [
      "安大略省 G 类驾照，满 2 年", "车辆保险含商业用途附加条款",
      "无犯罪记录证明（CPIC）", "可用 iOS / Android 手机", "SIN 及加拿大工作许可"
    ],
    driverEarnTitle: "参考收入", driverEarnCols: ["车型", "每单均值", "每周可接单"],
    driverEarn: [
      { a: "小型货车", b: "$38", c: "40 – 60" },
      { a: "厢式货车", b: "$64", c: "30 – 45" },
      { a: "方箱卡车", b: "$118", c: "18 – 28" }
    ],
    legalTitle: "隐私政策", legalUpdated: "最后更新：2026 年 8 月 1 日",
    legalToc: "本页目录",
    legalSections: [
      { h: "1. 我们收集的信息", b: "为完成运输订单，我们收集姓名、联系方式、取送地址、支付凭证以及订单相关的照片与签收记录。位置信息仅在订单进行期间从司机端采集。" },
      { h: "2. 信息的使用", b: "信息用于派单、计价、客服处理、欺诈防范与法定记录留存。我们不会将您的地址信息用于广告投放。" },
      { h: "3. 信息的共享", b: "承运司机仅能看到完成该订单所必需的信息。支付由持牌支付机构处理，我们不存储完整卡号。" },
      { h: "4. 数据留存", b: "订单记录依据加拿大税务与运输法规保留七年，之后匿名化处理。" },
      { h: "5. 您的权利（PIPEDA）", b: "您可随时查询、更正或要求删除个人信息。请联系 privacy@qhaul.ca，我们将在 30 日内答复。" }
    ],
    nfTitle: "找不到这个页面",
    nfBody: "链接可能已失效，或订单号输入有误。返回首页重新开始，或直接查询订单。",
    nfCode: "错误 404",
    tagline: "本地司机，真实的人，当日上门。",
    b2bFooter: "商务账户 · 月结发票 · 批量价格",
    privacy: "隐私政策", terms: "服务条款",
    footerNav: "网站导航"
  },
  en: {
    label: "English", labelShort: "EN", locName: "English (CA)",
    navHome: "Home", navQuote: "Get a quote", navTrack: "Track", navBusiness: "Business", navDrivers: "Drive with us", navAccount: "My bookings",
    signIn: "Sign in", signOut: "Sign out", signedInAs: "Signed in",
    region: "GTA · Ontario · Canada",
    heroTitle: "Need it moved? QHaul it.",
    heroSub: "Local drivers. Real people. Same-day service. Moving, delivery, hauling and marketplace pickup on one platform.",
    ctaQuote: "Get a quote", ctaTrack: "Track a booking",
    statJobs: "Jobs per month", statSameDay: "Same-day completion", statPickup: "Average pickup time",
    quickQuote: "Quick quote", pickup: "Pickup", dropoff: "Drop-off", service: "Service",
    pickupPh: "Street, city or postal code", dropoffPh: "Street, city or postal code",
    servicesTitle: "What we move", servicesSub: "Four services. One platform. The same local drivers every time.",
    svc: [
      { t: "Moving", b: "Apartment moves, single-item lifts, furniture swaps." },
      { t: "Delivery", b: "Same-day courier, business-to-customer, returns." },
      { t: "Hauling", b: "Junk removal, appliance pickup, large-item disposal." },
      { t: "Marketplace pickup", b: "Kijiji, Facebook Marketplace, auction pickups." }
    ],
    svcCta: "Start a quote",
    howTitle: "Three steps",
    steps: [
      { t: "Addresses and time", b: "Enter pickup and drop-off, pick same-day or a booked window." },
      { t: "Choose a vehicle", b: "Cargo van to five-tonne truck, with the price shown up front." },
      { t: "Driver arrives, you track", b: "See driver location, plate and ETA the moment the job is accepted." }
    ],
    localEyebrow: "Locally operated",
    localTitle: "Not an algorithm. A driver from your own city.",
    localBody: "QHaul drivers live in the GTA and know the buildings: loading docks, elevator bookings, condo access rules. A real person owns your job from pickup to signature.",
    b2bTitle: "Business accounts", b2bCta: "Open an account",
    b2b: [
      { t: "Net-terms invoicing", b: "Net 15 / Net 30" },
      { t: "Volume pricing", b: "Monthly tiers" },
      { t: "Integration", b: "REST API · Webhooks" }
    ],
    quoteTitle: "Get a quote", quoteSub: "About one minute",
    whenLabel: "Pickup time", sizeLabel: "Load size", vehicleLabel: "Choose a vehicle",
    contactLabel: "Contact", notesLabel: "Notes (access, floor, elevator)",
    notesPh: "e.g. rear loading dock, service elevator booked 2–3 pm",
    helperLabel: "Add a second mover (+$45 / hour)",
    estimate: "Estimate", total: "Total", bookNow: "Book now",
    priceNote: "Includes fuel and 15 minutes of loading at each end. HST not included. Extra time is billed per minute.",
    vehicles: [
      { n: "Small van", c: "Up to 40 cu ft · 1 mover", p: "from $49" },
      { n: "Cargo van", c: "Up to 250 cu ft · 1 mover", p: "from $79" },
      { n: "Cube van", c: "Up to 600 cu ft · 2 movers", p: "from $129" },
      { n: "5-tonne truck", c: "Full-home move · 2–3 movers", p: "from $189" }
    ],
    priceRows: [
      { l: "Base rate (cargo van)", v: "$79.00" },
      { l: "Distance 24.8 km", v: "$37.20" },
      { l: "Loading 30 min", v: "included" },
      { l: "Second mover", v: "$45.00" }
    ],
    total_v: "$161.20",
    trackTitle: "Track a booking", trackCta: "Track", statusLabel: "Current status", statusNow: "On the way",
    trackPh: "Booking number, e.g. QH-2026-04871",
    mapNote: "Live route · refreshed every 15 s",
    driverLabel: "Your driver", callDriver: "Call driver", shareEta: "Share ETA",
    timeline: [
      { t: "Booking created", b: "Card authorised online", m: "1:42 pm" },
      { t: "Driver accepted", b: "Wei L. · cube van · CBTK 481", m: "1:47 pm" },
      { t: "Arrived at pickup", b: "401 Bay St, Toronto", m: "2:05 pm" },
      { t: "On the way", b: "8.2 km from drop-off", m: "2:31 pm" },
      { t: "Delivered", b: "Awaiting signature photo", m: "est. 2:55 pm" }
    ],
    accountTitle: "My bookings", newBooking: "New booking",
    accountTiles: [
      { v: "3", l: "In progress" }, { v: "27", l: "Completed" }, { v: "$1,940", l: "Spend this month" }, { v: "Net 30", l: "Billing" }
    ],
    colId: "Booking", colRoute: "Route", colService: "Service", colStatus: "Status", colTotal: "Total",
    bookings: [
      { id: "QH-2026-04871", r: "401 Bay St → 88 Mill St", s: "Delivery", st: "On the way", tt: "$161.20" },
      { id: "QH-2026-04844", r: "12 Yonge St → 900 King St W", s: "Moving", st: "Completed", tt: "$412.00" },
      { id: "QH-2026-04810", r: "66 Wellesley St → transfer station", s: "Hauling", st: "Completed", tt: "$228.50" },
      { id: "QH-2026-04788", r: "Kijiji seller → 55 Bloor St", s: "Marketplace", st: "Completed", tt: "$96.00" },
      { id: "QH-2026-04771", r: "Mississauga → Scarborough", s: "Delivery", st: "Cancelled", tt: "$0.00" }
    ],
    bizTitle: "Business accounts built for fleets and storefronts",
    bizSub: "One dashboard, net-terms invoicing, volume pricing. Hand your last mile to local drivers.",
    bizCta: "Open an account", bizCta2: "Book a demo",
    bizFeatures: [
      { t: "Net-terms invoicing", b: "Net 15 or Net 30, consolidated monthly, multiple cost centres." },
      { t: "Volume pricing", b: "Tiers apply automatically as monthly volume grows. No renegotiation." },
      { t: "API integration", b: "REST booking, webhook status callbacks, bulk CSV import." },
      { t: "Named support", b: "15-minute response in business hours, human handling for exceptions." }
    ],
    bizTiersTitle: "Volume tiers", bizTierCols: ["Jobs per month", "Discount", "Billing"],
    bizTiers: [
      { a: "1 – 49", b: "Standard", c: "Credit card" },
      { a: "50 – 199", b: "-8%", c: "Net 15" },
      { a: "200 – 499", b: "-14%", c: "Net 30" },
      { a: "500+", b: "Custom", c: "Net 30 + dedicated vehicle" }
    ],
    driverTitle: "Drive your own van. Get paid weekly.",
    driverSub: "Your vehicle, your hours. Weekly payouts across the GTA, no franchise fee.",
    driverCta: "Start signing up", driverCta2: "See earnings detail",
    driverReqTitle: "What you need",
    driverReq: [
      "Ontario G licence, held 2+ years", "Insurance with commercial-use endorsement",
      "Criminal record check (CPIC)", "A working iOS or Android phone", "SIN and Canadian work authorisation"
    ],
    driverEarnTitle: "Reference earnings", driverEarnCols: ["Vehicle", "Average per job", "Jobs per week"],
    driverEarn: [
      { a: "Small van", b: "$38", c: "40 – 60" },
      { a: "Cargo van", b: "$64", c: "30 – 45" },
      { a: "Cube van", b: "$118", c: "18 – 28" }
    ],
    legalTitle: "Privacy policy", legalUpdated: "Last updated 1 August 2026",
    legalToc: "On this page",
    legalSections: [
      { h: "1. What we collect", b: "To complete a job we collect your name, contact details, pickup and drop-off addresses, payment authorisation, and job photos or proof of delivery. Location data is collected from the driver's device only while a job is active." },
      { h: "2. How we use it", b: "Dispatch, pricing, customer support, fraud prevention and statutory record keeping. We do not use your address data for advertising." },
      { h: "3. Who we share it with", b: "A driver sees only what is needed to complete the job. Payments are processed by a licensed provider; we never store full card numbers." },
      { h: "4. Retention", b: "Job records are kept for seven years under Canadian tax and transport rules, then anonymised." },
      { h: "5. Your rights under PIPEDA", b: "You may access, correct or request deletion of your personal information at any time. Write to privacy@qhaul.ca and we will respond within 30 days." }
    ],
    nfTitle: "This page could not be found",
    nfBody: "The link may have expired, or the booking number was mistyped. Start again from the home page, or look up a booking directly.",
    nfCode: "Error 404",
    tagline: "Local drivers. Real people. Same-day service.",
    b2bFooter: "B2B accounts · Net-terms invoicing · Volume pricing",
    privacy: "Privacy", terms: "Terms",
    footerNav: "Site"
  },
  fr: {
    label: "Français", labelShort: "FR", locName: "Français (CA)",
    navHome: "Accueil", navQuote: "Devis", navTrack: "Suivi", navBusiness: "Entreprises", navDrivers: "Devenir chauffeur", navAccount: "Mes réservations",
    signIn: "Se connecter", signOut: "Se déconnecter", signedInAs: "Connecté",
    region: "RGT · Ontario · Canada",
    heroTitle: "À déplacer ? QHaul s'en charge.",
    heroSub: "Des chauffeurs d'ici. De vraies personnes. Service le jour même. Déménagement, livraison, débarras et ramassage entre particuliers sur une seule plateforme.",
    ctaQuote: "Obtenir un devis", ctaTrack: "Suivre une réservation",
    statJobs: "Courses par mois", statSameDay: "Réalisé le jour même", statPickup: "Délai moyen de ramassage",
    quickQuote: "Devis rapide", pickup: "Ramassage", dropoff: "Livraison", service: "Service",
    pickupPh: "Rue, ville ou code postal", dropoffPh: "Rue, ville ou code postal",
    servicesTitle: "Ce que nous transportons", servicesSub: "Quatre services. Une plateforme. Les mêmes chauffeurs locaux.",
    svc: [
      { t: "Déménagement", b: "Appartements, pièces uniques, échange de meubles." },
      { t: "Livraison", b: "Coursier le jour même, entreprise-client, retours." },
      { t: "Débarras", b: "Enlèvement de rebuts, électroménagers, gros objets." },
      { t: "Ramassage annonces", b: "Kijiji, Marketplace, ventes aux enchères." }
    ],
    svcCta: "Faire un devis",
    howTitle: "Trois étapes",
    steps: [
      { t: "Adresses et heure", b: "Indiquez les adresses, choisissez le jour même ou une plage réservée." },
      { t: "Choisir un véhicule", b: "De la fourgonnette au camion de cinq tonnes, prix affiché d'avance." },
      { t: "Le chauffeur arrive, vous suivez", b: "Position, plaque et heure d'arrivée dès l'acceptation de la course." }
    ],
    localEyebrow: "Exploitation locale",
    localTitle: "Pas un algorithme. Un chauffeur de votre ville.",
    localBody: "Les chauffeurs QHaul habitent la région de Toronto et connaissent les immeubles : quais de chargement, réservation d'ascenseur, règles d'accès. Une vraie personne suit votre course du début à la signature.",
    b2bTitle: "Comptes entreprise", b2bCta: "Ouvrir un compte",
    b2b: [
      { t: "Facturation à terme", b: "Net 15 / Net 30" },
      { t: "Tarifs de volume", b: "Paliers mensuels" },
      { t: "Intégration", b: "API REST · Webhooks" }
    ],
    quoteTitle: "Obtenir un devis", quoteSub: "Environ une minute",
    whenLabel: "Heure de ramassage", sizeLabel: "Volume", vehicleLabel: "Choisir un véhicule",
    contactLabel: "Coordonnées", notesLabel: "Notes (accès, étage, ascenseur)",
    notesPh: "ex. quai arrière, ascenseur réservé de 14 h à 15 h",
    helperLabel: "Ajouter un second déménageur (+45 $ / heure)",
    estimate: "Estimation", total: "Total", bookNow: "Réserver",
    priceNote: "Carburant et 15 minutes de chargement à chaque extrémité inclus. TVH en sus. Le temps additionnel est facturé à la minute.",
    vehicles: [
      { n: "Petite fourgonnette", c: "Jusqu'à 40 pi³ · 1 personne", p: "dès 49 $" },
      { n: "Fourgonnette", c: "Jusqu'à 250 pi³ · 1 personne", p: "dès 79 $" },
      { n: "Camion cube", c: "Jusqu'à 600 pi³ · 2 personnes", p: "dès 129 $" },
      { n: "Camion 5 tonnes", c: "Déménagement complet · 2–3 personnes", p: "dès 189 $" }
    ],
    priceRows: [
      { l: "Tarif de base (fourgonnette)", v: "79,00 $" },
      { l: "Distance 24,8 km", v: "37,20 $" },
      { l: "Chargement 30 min", v: "inclus" },
      { l: "Second déménageur", v: "45,00 $" }
    ],
    total_v: "161,20 $",
    trackTitle: "Suivre une réservation", trackCta: "Suivre", statusLabel: "État actuel", statusNow: "En route",
    trackPh: "Numéro de réservation, ex. QH-2026-04871",
    mapNote: "Trajet en direct · actualisé aux 15 s",
    driverLabel: "Votre chauffeur", callDriver: "Appeler", shareEta: "Partager l'arrivée",
    timeline: [
      { t: "Réservation créée", b: "Carte autorisée en ligne", m: "13 h 42" },
      { t: "Chauffeur assigné", b: "Wei L. · camion cube · CBTK 481", m: "13 h 47" },
      { t: "Arrivé au ramassage", b: "401 Bay St, Toronto", m: "14 h 05" },
      { t: "En route", b: "à 8,2 km de la livraison", m: "14 h 31" },
      { t: "Livré", b: "Photo de signature attendue", m: "prévu 14 h 55" }
    ],
    accountTitle: "Mes réservations", newBooking: "Nouvelle réservation",
    accountTiles: [
      { v: "3", l: "En cours" }, { v: "27", l: "Terminées" }, { v: "1 940 $", l: "Dépenses ce mois" }, { v: "Net 30", l: "Facturation" }
    ],
    colId: "Réservation", colRoute: "Trajet", colService: "Service", colStatus: "État", colTotal: "Total",
    bookings: [
      { id: "QH-2026-04871", r: "401 Bay St → 88 Mill St", s: "Livraison", st: "En route", tt: "161,20 $" },
      { id: "QH-2026-04844", r: "12 Yonge St → 900 King St W", s: "Déménagement", st: "Terminée", tt: "412,00 $" },
      { id: "QH-2026-04810", r: "66 Wellesley St → écocentre", s: "Débarras", st: "Terminée", tt: "228,50 $" },
      { id: "QH-2026-04788", r: "Vendeur Kijiji → 55 Bloor St", s: "Ramassage", st: "Terminée", tt: "96,00 $" },
      { id: "QH-2026-04771", r: "Mississauga → Scarborough", s: "Livraison", st: "Annulée", tt: "0,00 $" }
    ],
    bizTitle: "Des comptes entreprise pensés pour les flottes et les commerces",
    bizSub: "Un seul tableau de bord, facturation à terme, tarifs de volume. Confiez votre dernier kilomètre à des chauffeurs d'ici.",
    bizCta: "Ouvrir un compte", bizCta2: "Réserver une démo",
    bizFeatures: [
      { t: "Facturation à terme", b: "Net 15 ou Net 30, regroupée mensuellement, plusieurs centres de coûts." },
      { t: "Tarifs de volume", b: "Les paliers s'appliquent automatiquement selon le volume mensuel." },
      { t: "Intégration API", b: "Réservation REST, rappels webhook, import CSV en lot." },
      { t: "Soutien nommé", b: "Réponse en 15 minutes aux heures d'affaires, traitement humain des exceptions." }
    ],
    bizTiersTitle: "Paliers de volume", bizTierCols: ["Courses par mois", "Remise", "Facturation"],
    bizTiers: [
      { a: "1 – 49", b: "Standard", c: "Carte de crédit" },
      { a: "50 – 199", b: "-8 %", c: "Net 15" },
      { a: "200 – 499", b: "-14 %", c: "Net 30" },
      { a: "500+", b: "Sur mesure", c: "Net 30 + véhicule dédié" }
    ],
    driverTitle: "Conduisez votre véhicule. Payé chaque semaine.",
    driverSub: "Votre véhicule, vos heures. Versements hebdomadaires dans la RGT, sans frais de franchise.",
    driverCta: "Commencer l'inscription", driverCta2: "Voir le détail des revenus",
    driverReqTitle: "Conditions",
    driverReq: [
      "Permis G de l'Ontario depuis 2 ans", "Assurance avec avenant usage commercial",
      "Vérification des antécédents (CPIC)", "Téléphone iOS ou Android fonctionnel", "NAS et autorisation de travail"
    ],
    driverEarnTitle: "Revenus de référence", driverEarnCols: ["Véhicule", "Moyenne par course", "Courses par semaine"],
    driverEarn: [
      { a: "Petite fourgonnette", b: "38 $", c: "40 – 60" },
      { a: "Fourgonnette", b: "64 $", c: "30 – 45" },
      { a: "Camion cube", b: "118 $", c: "18 – 28" }
    ],
    legalTitle: "Politique de confidentialité", legalUpdated: "Mise à jour le 1er août 2026",
    legalToc: "Sur cette page",
    legalSections: [
      { h: "1. Renseignements recueillis", b: "Pour exécuter une course, nous recueillons votre nom, vos coordonnées, les adresses de ramassage et de livraison, l'autorisation de paiement ainsi que les photos et preuves de livraison. La position est recueillie de l'appareil du chauffeur uniquement pendant la course." },
      { h: "2. Utilisation", b: "Affectation, tarification, service à la clientèle, prévention de la fraude et conservation légale des dossiers. Vos adresses ne servent jamais à la publicité." },
      { h: "3. Communication à des tiers", b: "Le chauffeur ne voit que ce qui est nécessaire à la course. Les paiements sont traités par un fournisseur agréé ; nous ne conservons aucun numéro de carte complet." },
      { h: "4. Conservation", b: "Les dossiers de course sont conservés sept ans selon les règles fiscales et de transport canadiennes, puis anonymisés." },
      { h: "5. Vos droits (LPRPDE)", b: "Vous pouvez consulter, corriger ou demander la suppression de vos renseignements en tout temps. Écrivez à privacy@qhaul.ca ; nous répondons sous 30 jours." }
    ],
    nfTitle: "Page introuvable",
    nfBody: "Le lien est peut-être expiré ou le numéro de réservation mal saisi. Repartez de l'accueil ou consultez directement une réservation.",
    nfCode: "Erreur 404",
    tagline: "Des chauffeurs d'ici. De vraies personnes. Service le jour même.",
    b2bFooter: "Comptes entreprise · Facturation à terme · Tarifs de volume",
    privacy: "Confidentialité", terms: "Conditions",
    footerNav: "Navigation"
  }
};
